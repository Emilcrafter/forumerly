module.exports = {
    
    session_secret: "Hello" // Redis
    
};